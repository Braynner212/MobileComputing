package com.example.upjwelrry;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class OrdDetail extends AppCompatActivity {

    private Intent In;
    private ArrayList<Order> Orders;
    private TextView TxtOrderTye, TxtPrice, TxtMaterial, TxtStone, TxtMark, Txt;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ord_detail);

        In = getIntent();
        Orders = Data.Get();

        int Position = In.getIntExtra("position", 0);

        TxtOrderTye = (TextView)findViewById(R.id.TxtOrderType);
        TxtPrice = (TextView)findViewById(R.id.TxtPrice);
        TxtMaterial = (TextView) findViewById(R.id.TxtMaterial);
        TxtStone = (TextView)findViewById(R.id.TxtStone);
        TxtMark = (TextView)findViewById(R.id.TxtSignature);
        Txt = (TextView)findViewById(R.id.Text1);

        loadData(Orders.get(Position));

    }

    private void loadData(Order Order){
        TxtOrderTye.setText(Order.getJewelType());
        TxtPrice.setText(Order.getPrice());
        TxtMaterial.setText(Order.getMaterial());
        TxtStone.setText(Order.getStone());
        TxtMark.setText(Order.getSignature());

        if (TextUtils.isEmpty(Order.getSignature())){
            Txt.setVisibility(View.INVISIBLE);
            TxtMark.setVisibility(View.INVISIBLE);
        }else{
            Txt.setVisibility(View.VISIBLE);
            TxtMark.setVisibility(View.VISIBLE);
        }

    }
}